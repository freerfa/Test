const UserActionTypes = {
  SAVE_USER_DATA : 'SAVE_USER_DATA',
  LOG_OUT_USER : 'LOG_OUT_USER',
  ALL_DATA: 'ALL_DATA',
  ADD_CATEGORY:'ADD_CATEGORY'
}

export default UserActionTypes;