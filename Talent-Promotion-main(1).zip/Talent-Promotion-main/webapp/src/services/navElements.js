export const navs = [
  {
    name: "SignUp",
    path: "/signUp",
    cname: "nav-item",
  },
  {
    name: "Login",
    path: "/login",
    cname: "nav-item",
  },
  {
    name: "About Us",
    path: "/about_us",
    cname: "nav-item",
  },
  {
    name: "Contact Us",
    path: "/contact_us",
    cname: "nav-item",
  },
  {
    name: "Me",
    path: "/me",
    cname: "nav-item",
  },
];






 



export const sideBar = [
  { 
    name:'All'
  },
  {
    name: "Electronics",
  },
  {
    name: "Home Furniture",
  },
  {
    name: "Appliances",
  },
  {
    name: "Fashion",
  },
  {
    name: "Beauty",
  },
  {
    name: "Health",
  },
  {
    name: "Media",
  },
  { name:"Blacksmit"}
];
