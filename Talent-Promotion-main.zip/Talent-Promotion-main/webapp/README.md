Web app for a Talent's promotion App 

