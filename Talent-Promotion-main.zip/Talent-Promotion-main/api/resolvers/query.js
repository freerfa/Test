module.exports ={
  test:() => 'Testing if this is working fine'
}